import unittest
from foo_parameterization.core import calculate_volume

class TestFooParameterization(unittest.TestCase):

    def test_calculate_volume(self):
        self.assertAlmostEqual(calculate_volume(1), 4 / 3 * 3.141592653589793)
        self.assertAlmostEqual(calculate_volume(2), 4 / 3 * 3.141592653589793 * 8)
        
    def test_invalid_radius(self):
        with self.assertRaises(ValueError):
            calculate_volume(-1)
        with self.assertRaises(ValueError):
            calculate_volume(0)
        with self.assertRaises(TypeError):
            calculate_volume("a string")

if __name__ == '__main__':
    unittest.main()