
def validate_radius(radius):
    if not isinstance(radius, (int, float)):
        raise TypeError("Radius must be a number")
    if radius <= 0:
        raise ValueError("Radius must be greater than zero")