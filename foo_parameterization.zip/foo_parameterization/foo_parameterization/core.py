
import math
from .utils import validate_radius

def complex_foo_parameterization(radius):
    
    return 4 / 3 * math.pi * radius ** 3

def calculate_volume(radius):
    validate_radius(radius)
    return complex_foo_parameterization(radius)