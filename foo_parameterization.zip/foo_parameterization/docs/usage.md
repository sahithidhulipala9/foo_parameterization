Foo parameterization is used to calculate the volume of the sphere using radius.

This file explains the package structure in detail.

In Foo_parameterization folder-  
Docs ***Documentation***
Examples->example.ipynb ***Example*** # users can calculate volume of a sphere
example.ipynb -> users can calculate volume of sphere using radius directly from this file.
foo_parameterization ***code***
core.py-> contains core logic
utils.py-> contains validation
tests->  unit test cases
setup.py -> configuration details 
# execute using this command - python setup.py install 
it creates files foo_parameterization.egg-info , build, lib folders are for understanding package structure 

**open folder in visual studio and install necessary plugin extensions**