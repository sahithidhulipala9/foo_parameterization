### `calculate_volume(radius)`

Calculates the volume of a sphere using the Foo et al. parameterization.

**Parameters:**
- `radius` (float): The radius of the sphere.

**Returns:**
- float: The volume of the sphere.

**Raises:**
- `TypeError`: If `radius` is not a number.
- `ValueError`: If `radius` is not greater than zero.