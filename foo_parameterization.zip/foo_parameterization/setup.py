from setuptools import setup, find_packages # type: ignore
#download setuptools using pip install setuptools in terminal
setup(
    name='foo_parameterization',  
    version='0.1',  
    packages=find_packages(), 
    install_requires=[],  
    author='Lakshmi Sahithi Dhulipala',  
    author_email='ddhulipalasahithi@gmail.com',  
    description='This package provides complex parameterization for calculating the volume of a sphere given its radius', 
    url='https://github.com/sahithidhulipala9/foo_parameterization',  
    license='MIT',  
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)

#python setup.py install - command is for defining and configuring python package for disturbution.
